package com.example.climafacil

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
