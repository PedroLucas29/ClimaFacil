import 'package:flutter/material.dart';
import 'package:climafacil/models/constants.dart';
import 'package:climafacil/ui/welcome.dart';

class GetStarted extends StatelessWidget {
  const GetStarted({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Constants myConstants = Constants();

    Size size = MediaQuery.of(context).size;

    return Scaffold(
      body: Container(
        width: size.width,
        height: size.height,
        color: myConstants.primaryColor.withOpacity(.5),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.asset('assets/get-started.png'),
              const SizedBox(
                height: 30,
              ),
              GestureDetector(
                onTap: () {
                  Navigator.pushReplacement(context,
                      MaterialPageRoute(builder: (context) => const Welcome()));
                },
                child: Container(
                  height: 50,
                  width: size.width * 0.7,
                  decoration: BoxDecoration(
                    color: myConstants.primaryColor,
                    borderRadius: const BorderRadius.all(Radius.circular(10)),
                  ),
                  child: const Center(
                    child: Text(
                      'Entrar',
                      style: TextStyle(color: Colors.white, fontSize: 18),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/*
  Esta é a primeira interface exibida ao abrir o aplicativo, funcionando como uma tela de introdução.

  Ela contém uma imagem e um botão personalizado com o texto “Entrar”. 
  Ao tocar nesse botão, o usuário é redirecionado para a tela de boas-vindas (Welcome).

  O uso de MediaQuery garante que os elementos da tela se adaptem de forma responsiva a diferentes tamanhos de dispositivos.

  O GestureDetector foi utilizado para capturar o toque no botão de forma personalizada,
  permitindo maior controle visual e de comportamento, em vez de utilizar um botão padrão como o ElevatedButton.
*/
