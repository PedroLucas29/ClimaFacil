import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart'; // Para formatação local
import 'package:climafacil/models/city.dart';
import 'package:climafacil/models/constants.dart';
import 'package:climafacil/ui/detail_page.dart';
import 'package:climafacil/widgets/weather_item.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final Constants myConstants = Constants();

  int temperature = 0;
  int maxTemp = 0;
  String weatherStateName = 'Carregando...';
  int humidity = 0;
  double windSpeed = 0;

  String currentDate = 'Carregando...';
  String weatherIconCode = '';
  String location = 'São Paulo';

  final String apiKey = '59c489674841d1bba51f92b2e7ab5141';

  List<String> cities = [];
  List consolidatedWeatherList = [];

  int _selectedDayIndex = 0;

  @override
  void initState() {
    super.initState();

    cities = City.citiesList.map((e) => e.city).toList();

    Future.microtask(() async {
      await initializeDateFormatting('pt_BR', null);
      fetchWeatherData();
      fetchForecastData();
    });
  }

  Future<void> fetchWeatherData() async {
    final uri = Uri.https('api.openweathermap.org', '/data/2.5/weather', {
      'q': location,
      'units': 'metric',
      'appid': apiKey,
      'lang': 'pt',
    });

    try {
      final response = await http.get(uri);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);

        setState(() {
          temperature = data['main']['temp'].round();
          maxTemp = data['main']['temp_max'].round();
          humidity = data['main']['humidity'].round();
          windSpeed = (data['wind']['speed'] as num).toDouble();
          weatherStateName = data['weather'][0]['description'];
          weatherIconCode = data['weather'][0]['icon'];
          currentDate =
              DateFormat('EEEE, d MMMM', 'pt_BR').format(DateTime.now());
        });
      } else {
        debugPrint(
            'Erro ao buscar dados do tempo: status ${response.statusCode}');
      }
    } catch (e) {
      debugPrint('Erro ao buscar dados do tempo: $e');
    }
  }

  Future<void> fetchForecastData() async {
    final uri = Uri.https('api.openweathermap.org', '/data/2.5/forecast', {
      'q': location,
      'units': 'metric',
      'appid': apiKey,
      'lang': 'pt',
    });

    try {
      final response = await http.get(uri);

      if (response.statusCode == 200) {
        final data = json.decode(utf8.decode(response.bodyBytes));

        // Filtra os horários das 12h para 5 dias
        List forecastList = (data['list'] as List).where((item) {
          return (item['dt_txt'] as String).contains('12:00:00');
        }).toList();

        setState(() {
          consolidatedWeatherList = forecastList;
          _selectedDayIndex = 0;
        });
      } else {
        debugPrint('Erro ao buscar forecast: status ${response.statusCode}');
        setState(() {
          consolidatedWeatherList = [];
          _selectedDayIndex = 0;
        });
      }
    } catch (e) {
      debugPrint('Erro ao buscar forecast: $e');
      setState(() {
        consolidatedWeatherList = [];
        _selectedDayIndex = 0;
      });
    }
  }

  void _changeDay(int delta) {
    setState(() {
      _selectedDayIndex = (_selectedDayIndex + delta)
          .clamp(0, consolidatedWeatherList.length - 1);
    });
  }

  final Shader linearGradient = const LinearGradient(
    colors: <Color>[Color(0xfff2f2f2), Color(0xff9AC6F3)],
  ).createShader(const Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        centerTitle: false,
        titleSpacing: 0,
        backgroundColor: Color(0xff360769),
        elevation: 0,
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          width: size.width,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              ClipRRect(
                borderRadius: const BorderRadius.all(Radius.circular(10)),
                child: Image.asset(
                  'assets/profile.png',
                  width: 40,
                  height: 40,
                ),
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(
                    'assets/pin.png',
                    width: 20,
                  ),
                  const SizedBox(width: 4),
                  DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: location,
                      dropdownColor: const Color(0xff360769),
                      icon: const Icon(
                        Icons.keyboard_arrow_down,
                        color: Colors.white, // 👉 deixa o ícone branco
                      ),
                      style: const TextStyle(
                          color:
                              Colors.white), // 👉 texto da cidade selecionada
                      items: cities
                          .map((city) => DropdownMenuItem(
                                value: city,
                                child: Text(
                                  city,
                                  style: const TextStyle(
                                      color: Colors.white), // 👉 itens da lista
                                ),
                              ))
                          .toList(),
                      onChanged: (newValue) {
                        if (newValue != null && newValue != location) {
                          setState(() {
                            location = newValue;
                          });
                          fetchWeatherData();
                          fetchForecastData();
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  location,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 30),
                ),
                Text(
                  currentDate,
                  style: const TextStyle(color: Colors.grey, fontSize: 16),
                ),
                const SizedBox(height: 50),
                Container(
                  width: size.width,
                  height: 200,
                  decoration: BoxDecoration(
                    color: myConstants.primaryColor,
                    borderRadius: BorderRadius.circular(15),
                    boxShadow: [
                      BoxShadow(
                        color: myConstants.primaryColor.withOpacity(0.5),
                        offset: const Offset(0, 25),
                        blurRadius: 10,
                        spreadRadius: -12,
                      ),
                    ],
                  ),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Positioned(
                        top: -40,
                        left: 20,
                        child: weatherIconCode.isEmpty
                            ? const SizedBox.shrink()
                            : Image.network(
                                'https://openweathermap.org/img/wn/$weatherIconCode@4x.png',
                                width: 150,
                              ),
                      ),
                      Positioned(
                        bottom: 30,
                        left: 20,
                        child: Text(
                          weatherStateName,
                          style: const TextStyle(
                              color: Colors.white, fontSize: 20),
                        ),
                      ),
                      Positioned(
                        top: 20,
                        right: 20,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Text(
                                temperature.toString(),
                                style: TextStyle(
                                  fontSize: 80,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                            Text(
                              '°C',
                              style: TextStyle(
                                fontSize: 40,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 50),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      weatherItem(
                        text: 'Vento',
                        value: windSpeed.round(),
                        unit: ' km/h',
                        imageUrl: 'assets/windspeed.png',
                      ),
                      weatherItem(
                        text: 'Umidade',
                        value: humidity,
                        unit: '%',
                        imageUrl: 'assets/humidity.png',
                      ),
                      weatherItem(
                        text: 'Temp. Máx',
                        value: maxTemp,
                        unit: '°C',
                        imageUrl: 'assets/max-temp.png',
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 50),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'Hoje',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
                    ),
                    Text(
                      'Próximos 5 dias',
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 18,
                        color: myConstants.tertiaryColor,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Substitui PageView por card + botões
                consolidatedWeatherList.isEmpty
                    ? const Center(
                        child: Text('Carregando previsão...'),
                      )
                    : Column(
                        children: [
                          Container(
                            margin: const EdgeInsets.symmetric(vertical: 20),
                            padding: const EdgeInsets.all(20),
                            decoration: BoxDecoration(
                              color: Color(0xff7107e3),
                              borderRadius: BorderRadius.circular(10),
                              boxShadow: [
                                BoxShadow(
                                  offset: const Offset(0, 1),
                                  blurRadius: 5,
                                  color: Colors.white10.withOpacity(0.2),
                                ),
                              ],
                            ),
                            child: _buildDayForecastCard(
                                consolidatedWeatherList[_selectedDayIndex]),
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              ElevatedButton(
                                onPressed: _selectedDayIndex > 0
                                    ? () => _changeDay(-1)
                                    : null,
                                child: const Icon(Icons.arrow_back),
                              ),
                              const SizedBox(width: 20),
                              ElevatedButton(
                                onPressed: _selectedDayIndex <
                                        consolidatedWeatherList.length - 1
                                    ? () => _changeDay(1)
                                    : null,
                                child: const Icon(Icons.arrow_forward),
                              ),
                            ],
                          ),
                        ],
                      ),

                const SizedBox(height: 10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDayForecastCard(dynamic forecast) {
    var temp = (forecast['main']['temp'] as num).round();
    var dateStr = forecast['dt_txt'] as String;
    var parsedDate = DateTime.parse(dateStr);
    var newDate = DateFormat('EEE, d MMM', 'pt_BR').format(parsedDate);
    var iconCode = forecast['weather'][0]['icon'] as String;
    String iconUrl = 'https://openweathermap.org/img/wn/$iconCode@2x.png';

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          newDate,
          style: TextStyle(
            fontSize: 18,
            color: myConstants.tertiaryColor,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 10),
        Image.network(iconUrl, width: 70),
        const SizedBox(height: 10),
        Text(
          "$temp°C",
          style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
            color: myConstants.tertiaryColor,
          ),
        ),
      ],
    );
  }
}

/*
  A tela Home é o núcleo funcional do aplicativo, responsável por exibir as informações climáticas da cidade selecionada pelo usuário.

  🔍 Funcionalidade principal:
  - Realiza duas requisições à API do OpenWeather:
    1. `/weather` → Clima atual (temperatura, umidade, vento, descrição e ícone).
    2. `/forecast` → Previsão dos próximos 5 dias, filtrando apenas os dados do meio-dia para representar melhor o clima diário.

  🔁 Ciclo de funcionamento:
  - No método initState, a tela é inicializada com a cidade padrão "São Paulo".
  - Em seguida, são feitas as chamadas à API para obter os dados atuais e a previsão futura.
  - O usuário pode alterar a cidade através de um Dropdown, que dispara novas requisições automaticamente.

  📱 Interface:
  - Cartão principal com temperatura atual e ícone correspondente.
  - Indicadores rápidos: velocidade do vento, umidade e temperatura máxima.
  - Lista com previsão diária e botões de navegação (← / →) para alternar entre os dias.

  🔧 Tecnologias e recursos utilizados:
  - `http.get` para consumo da API.
  - `setState` para atualizar dinamicamente os dados na interface.
  - `DateFormat` com localização pt_BR para exibir datas em português.
  - Widgets reutilizáveis, como `weatherItem` e `_buildDayForecastCard`, para manter a estrutura do código organizada e modular.
  - Ícones climáticos carregados dinamicamente via `Image.network`, com base nos códigos recebidos da API.

  Essa tela une design responsivo, integração com API e componentes reutilizáveis, oferecendo uma experiência fluida e informativa ao usuário.
*/
