import 'package:flutter/material.dart';

class Constants {
  final Color primaryColor = const Color(0xff7107e3);
  final Color secondaryColor = const Color(0xffa54bf9);
  final Color tertiaryColor = const Color(0xfffdf9ff);
}

/*
  Esta classe `Constants` centraliza a definição das cores principais usadas na interface do aplicativo.

  - primaryColor: cor primária (roxo escuro), geralmente usada para botões ou elementos de destaque.
  - secondaryColor: cor secundária (roxo claro), aplicada em fundos ou elementos complementares.
  - tertiaryColor: cor terciária (branco suave), utilizada em planos de fundo ou áreas com menor destaque.

  O uso dessa classe permite manter um padrão visual consistente em todo o app, facilitando a manutenção e personalização do tema.
*/
