class City {
  bool isSelected;
  final String city;
  final String country;
  final bool isDefault;

  City({
    required this.isSelected,
    required this.city,
    required this.country,
    required this.isDefault,
  });

  static List<City> citiesList = [
    City(
        isSelected: true,
        city: 'São Paulo',
        country: 'Brasil',
        isDefault: true),
    City(
        isSelected: false,
        city: 'Rio de Janeiro',
        country: 'Brasil',
        isDefault: false),
    City(
        isSelected: false,
        city: 'Brasília',
        country: 'Brasil',
        isDefault: false),
    City(
        isSelected: false,
        city: 'Salvador',
        country: 'Brasil',
        isDefault: false),
    City(
        isSelected: false,
        city: 'Fortaleza',
        country: 'Brasil',
        isDefault: false),
    City(
        isSelected: false,
        city: 'Belo Horizonte',
        country: 'Brasil',
        isDefault: false),
    City(
        isSelected: false, city: 'Manaus', country: 'Brasil', isDefault: false),
    City(
        isSelected: false,
        city: 'Curitiba',
        country: 'Brasil',
        isDefault: false),
    City(
        isSelected: false, city: 'Recife', country: 'Brasil', isDefault: false),
    City(
        isSelected: false,
        city: 'Porto Alegre',
        country: 'Brasil',
        isDefault: false),
  ];

  static List<City> getSelectedCities() {
    return citiesList.where((city) => city.isSelected).toList();
  }
}

/*
  Esta classe representa um modelo de cidade utilizado no aplicativo para controle da seleção de locais para previsão do tempo.
  
  - Atributos:
    - isSelected: indica se a cidade está selecionada pelo usuário.
    - city: nome da cidade.
    - country: país da cidade.
    - isDefault: identifica se essa é a cidade padrão inicial ao abrir o app.

  - citiesList: é uma lista estática que armazena as principais cidades brasileiras disponíveis no app.
  
  - getSelectedCities(): método estático que retorna uma lista contendo apenas as cidades que estão selecionadas.

  Essa estrutura facilita o gerenciamento das cidades exibidas e permite selecionar múltiplas cidades para exibição de dados meteorológicos.
*/
