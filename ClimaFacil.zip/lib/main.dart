import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:climafacil/ui/get_started.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('pt_BR');

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Clima Fácil',
      debugShowCheckedModeBanner: false,
      darkTheme: ThemeData(
        // Define o tema escuro do app.
        brightness: Brightness.dark,
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Color(0xff360769),
      ),
      themeMode: ThemeMode
          .dark, // força modo escuro; use ThemeMode.system para seguir o sistema
      home: const GetStarted(),
    );
  }
}
// O main.dart é o ponto de entrada do app.
// Ele configura a formatação de datas para o Brasil, o tema visual (claro e escuro) e define a tela inicial como GetStarted.
// Também inclui boas práticas como o uso de WidgetsFlutterBinding.ensureInitialized() para garantir que tudo esteja pronto antes de carregar o app.
