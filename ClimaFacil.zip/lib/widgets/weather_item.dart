import 'package:flutter/material.dart';

class weatherItem extends StatelessWidget {
  const weatherItem({
    Key? key,
    required this.value,
    required this.text,
    required this.unit,
    required this.imageUrl,
  }) : super(key: key);

  final int value;
  final String text;
  final String unit;
  final String imageUrl;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          text,
          style: const TextStyle(
            color: Color(0xe7ffffff),
          ),
        ),
        const SizedBox(
          height: 8,
        ),
        Container(
          padding: const EdgeInsets.all(10.0),
          height: 60,
          width: 60,
          decoration: const BoxDecoration(
            color: Color(0xff7107e3),
            borderRadius: BorderRadius.all(Radius.circular(15)),
          ),
          child: Image.asset(imageUrl),
        ),
        const SizedBox(
          height: 8,
        ),
        Text(
          value.toString() + unit,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        )
      ],
    );
  }
}

/*
  Este widget `weatherItem` é um componente reutilizável que exibe um item com dados meteorológicos (como vento, umidade, ou temperatura).

  - Parâmetros:
    - value: valor numérico (ex: 22, 75, etc.).
    - text: descrição do dado (ex: "Wind Speed", "Humidity").
    - unit: unidade do valor (ex: "km/h", "%", "°C").
    - imageUrl: caminho do ícone relacionado ao dado (ex: ícone de vento ou gota d'água).

  O layout é vertical, contendo o título, um ícone centralizado em uma caixa roxa estilizada, e o valor com unidade abaixo.
  Este widget é usado na tela de detalhes para mostrar informações climáticas de forma visual e organizada.
*/
